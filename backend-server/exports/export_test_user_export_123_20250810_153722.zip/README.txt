JobSwitch.ai Data Export
========================

Export ID: export_test_user_export_123_20250810_153722
User ID: test_user_export_123
Export Date: 2025-08-10T15:37:22.876032
Total Records: 0
Tables Exported: 0

This export contains all your personal data stored in JobSwitch.ai as of the export date.

Files Included:
- data.json: Complete data export in JSON format
- csv_files/: Individual CSV files for each data table
- metadata.csv: Export metadata and statistics
- README.txt: This file

Data Tables:
- user_profile: Basic user account information
- profile_details: Detailed user profile information
- skills: User skills and proficiency levels
- resumes: Resume versions and optimizations
- job_applications: Job application history and status
- interview_sessions: Interview preparation sessions and feedback
- networking_campaigns: Networking campaigns and outreach activities
- career_roadmaps: Career planning and goal tracking
- ai_interactions: AI agent interactions and task history

GDPR Compliance:
This export is provided in compliance with GDPR Article 20 (Right to data portability).
You have the right to receive your personal data in a structured, commonly used, and machine-readable format.

For questions about this export or your data rights, please contact support@jobswitch.ai